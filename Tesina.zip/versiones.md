# Versiones

## 2021-09-27

Primera entrega.

## 2021-10-12

- Expansión de la conclusiones.
- Mención al trabajo presentado en el SIIIO en el marco de la tesina.

## 2021-11-21
- En al introducción, página 2, se cambia "Este segundo enfoque es un poco contra-intuitivo, pues rompe uno de los principios de la teoría de juegos: la toma de decisiones de cada jugador se considera siempre como procesos independientes uno del otro." por "Este segundo enfoque es un poco contra-intuitivo, pues una interpretación común de los juegos estratégicos es que la toma de decisiones de cada jugador son procesos independientes uno del otro."
- En los conceptos previos, página 8, se quita la frase "Uno de los teoremas fundacionales del área, conocido como el Teorema de Minimax [26] establece que todos poseen al menos un equilibrio de Nash puro y a la ganancia para el jugador fila en un equilibrio la llamamos valor del juego (pues es la misma en todos
los equilibrios)."
- En el lema 4.2.2, página 20 se cambia juego ficticio simultáneo por alternante.
- En los conceptos previos, página 10, se cambia "conjunto de menor respuesta" por "conjunto de mejor respuesta".
- En al definición 3.4.2, página 11, se cambia "... si existe un equilibrio de Nash mixto tal que... " por "si existe un equilibrio de Nash mixto (x^*, y^*) tal que ...".
- En la tabla 4.1 se corrige el valor de x en la fila 2^k.
- Se lleva toda la bibliografía al mismo formato.